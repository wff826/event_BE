# api/routers/channel_webhook.py
import os, json, hmac, hashlib, base64, logging
from fastapi import APIRouter, Request, HTTPException
from fastapi.responses import JSONResponse
from dotenv import load_dotenv

from api.clients.channeltalk_client import send_message_to_userchat
from api.db.session import get_session
from api.db.crud import upsert_user, add_inquery, get_recent_inqueries
from api.db.models import ChatLog  # 봇 로그 저장에 사용

load_dotenv()
logging.basicConfig(level=logging.INFO)

router = APIRouter(prefix="/channel", tags=["channel"])

WEBHOOK_SIGNING_SECRET = os.getenv("CHANNELTALK_WEBHOOK_SECRET", "") or ""
WEBHOOK_QUERY_TOKEN    = os.getenv("CHANNELTALK_WEBHOOK_TOKEN", "") or ""
CHANNEL_DEBUG          = os.getenv("CHANNEL_DEBUG", "false").lower() in ("1", "true", "yes", "y")

SIGNING_ENABLED = bool(WEBHOOK_SIGNING_SECRET)
TOKEN_ENABLED   = bool(WEBHOOK_QUERY_TOKEN)


# ===== 서명/토큰 검증 =====
def verify_signature(raw: bytes, sig: str | None) -> bool:
    if not SIGNING_ENABLED:
        return True
    if not sig:
        return False
    dig = hmac.new(WEBHOOK_SIGNING_SECRET.encode(), raw, hashlib.sha256).digest()
    expect = base64.b64encode(dig).decode()
    return hmac.compare_digest(expect, sig)

def verify_query_token(tok: str | None) -> bool:
    if not TOKEN_ENABLED:
        return True
    if not tok:
        return False
    return hmac.compare_digest(tok, WEBHOOK_QUERY_TOKEN)

def is_verified(request: Request, raw: bytes) -> bool:
    return verify_signature(raw, request.headers.get("X-Signature")) \
        or verify_query_token(request.query_params.get("token"))


# ===== 추출 유틸 =====
def extract_user_chat_id(payload: dict) -> str | None:
    ent = payload.get("entity") or {}
    if isinstance(ent, dict) and ent.get("chatId") is not None:
        return str(ent["chatId"])

    data = payload.get("data") or {}
    for k in ("userChatId", "chatId"):
        v = data.get(k)
        if v is not None:
            return str(v)

    msgs = payload.get("messages")
    if isinstance(msgs, list) and msgs and isinstance(msgs[0], dict):
        cid = msgs[0].get("chatId")
        if cid is not None:
            return str(cid)
    return None

def extract_text(payload: dict) -> str:
    ent = payload.get("entity") or {}
    if isinstance(ent, dict):
        t = (ent.get("plainText") or "").strip()
        if t:
            return t
        blocks = ent.get("blocks") or []
        if isinstance(blocks, list) and blocks and isinstance(blocks[0], dict):
            if blocks[0].get("type") == "text":
                t = (blocks[0].get("value") or "").strip()
                if t:
                    return t

    msgs = payload.get("messages") or []
    if isinstance(msgs, list) and msgs and isinstance(msgs[0], dict):
        t = (msgs[0].get("plainText") or "").strip()
        if t:
            return t
        blocks = msgs[0].get("blocks") or []
        if isinstance(blocks, list) and blocks and isinstance(blocks[0], dict):
            if blocks[0].get("type") == "text":
                t = (blocks[0].get("value") or "").strip()
                if t:
                    return t

    data = payload.get("data")
    if isinstance(data, dict):
        t = (data.get("plainText") or "").strip()
        if t:
            return t
    return ""

def extract_fullname(payload: dict) -> str | None:
    refers = payload.get("refers") or {}
    if isinstance(refers, dict):
        u = refers.get("user") or {}
        if isinstance(u, dict):
            name = u.get("name")
            return str(name) if name else None
    ent = payload.get("entity") or {}
    if isinstance(ent, dict):
        name = ent.get("name")
        if name:
            return str(name)
    return None

def split_name(fullname: str | None):
    if not fullname:
        return None, None
    p = str(fullname).strip().split(maxsplit=1)
    return (p[0], p[1]) if len(p) > 1 else (p[0], None)

def combine_name(first: str | None, last: str | None) -> str | None:
    if first and last:
        return f"{first} {last}"
    return first or last or None

def classify_actor(payload: dict) -> str:
    """행위자(Actor) 판별: 'user' | 'bot' | 'unknown'"""
    ent = payload.get("entity") or {}
    if isinstance(ent, dict):
        pt = ent.get("personType")
        if pt in ("user", "bot"):
            return pt

    msgs = payload.get("messages")
    if isinstance(msgs, list) and msgs:
        pt = (msgs[0] or {}).get("personType")
        if pt in ("user", "bot"):
            return pt

    refers = payload.get("refers") or {}
    online = refers.get("online") or {}
    if isinstance(online, dict):
        pt = online.get("personType")
        if pt in ("user", "bot"):
            return pt

    return "unknown"

def extract_owner_id(payload: dict) -> str | None:
    """
    채팅 소유자(Owner) = 최종 사용자 ID
    우선순위:
      1) refers.userChat.userId
      2) refers.user.id
      3) refers.online.personId
      4) entity.personId (fallback)
    """
    refers = payload.get("refers") or {}
    if isinstance(refers, dict):
        user_chat = refers.get("userChat") or {}
        if isinstance(user_chat, dict) and user_chat.get("userId"):
            return str(user_chat["userId"])

        u = refers.get("user") or {}
        if isinstance(u, dict) and u.get("id"):
            return str(u["id"])

        online = refers.get("online") or {}
        if isinstance(online, dict) and online.get("personId"):
            return str(online["personId"])

    ent = payload.get("entity") or {}
    if isinstance(ent, dict) and ent.get("personId"):
        return str(ent["personId"])

    return None


# ===== 디버그 유틸 =====
def _mask_payload_for_log(raw_text: str) -> str:
    try:
        obj = json.loads(raw_text)
    except Exception:
        return raw_text
    try:
        if isinstance(obj.get("refers"), dict) and isinstance(obj["refers"].get("user"), dict):
            if "name" in obj["refers"]["user"] and obj["refers"]["user"]["name"]:
                obj["refers"]["user"]["name"] = "*****"
    except Exception:
        pass
    return json.dumps(obj, ensure_ascii=False)


# ===== 비즈 유틸 =====
def route_reply(text: str) -> str:
    t = (text or "").lower().strip()
    if t == "/ping":
        return "pong 🏓"
    if t.startswith("/help"):
        return "명령어: /ping, /help, /history (최근 문의 5건), /inq <내용>"
    return "문의가 접수되었어요. 최대한 빨리 답변드릴게요 🙏"


# ===== 사용자 메시지 처리(명령/일반) =====
async def _process_user_and_reply(
    owner_id: str,
    f_name: str | None,
    l_name: str | None,
    user_chat_id: str,
    text: str,
):
    display_name = combine_name(f_name, l_name)
    t = (text or "").lower().strip()

    if t.startswith("/history"):
        async with get_session() as s:
            rows = await get_recent_inqueries(s, user_id=owner_id, limit=5)
        lines = [f"- {r.message}" for r in rows] or ["(문의 없음)"]
        reply = "최근 문의:\n" + "\n".join(lines)
        await send_message_to_userchat(user_chat_id, reply)
        return

    if t.startswith("/inq"):
        body = text.split(" ", 1)[1].strip() if " " in (text or "") else ""
        async with get_session() as s:
            await upsert_user(s, user_id=owner_id, name=display_name)
            await add_inquery(s, user_id=owner_id, content=(body or "(내용 없음)"))
        await send_message_to_userchat(user_chat_id, "문의가 접수되었어요. 최대한 빨리 답변드릴게요 🙏")
        return

    # default: 일반 텍스트도 문의로 저장
    async with get_session() as s:
        await upsert_user(s, user_id=owner_id, name=display_name)
        log_id = await add_inquery(s, user_id=owner_id, content=(text or "(내용 없음)"))
        if CHANNEL_DEBUG:
            logging.info("DBG :: saved user log_id=%s uid=%s msg=%r", log_id, owner_id, text)
    await send_message_to_userchat(user_chat_id, route_reply(text))


# ===== 웹훅 엔드포인트 =====
@router.post("/webhook")
async def channel_webhook(request: Request):
    raw = await request.body()

    if CHANNEL_DEBUG:
        try:
            raw_text = raw.decode("utf-8", errors="replace")
        except Exception:
            raw_text = "<decode failed>"
        logging.info("\n===== WEBHOOK RAW PAYLOAD START =====\n%s\n===== WEBHOOK RAW PAYLOAD END =====",
                     _mask_payload_for_log(raw_text))

    if not is_verified(request, raw):
        raise HTTPException(status_code=401, detail="unauthorized webhook")

    try:
        payload = json.loads(raw.decode("utf-8"))
    except Exception:
        payload = {}

    # 공통 추출 (Owner는 최종 사용자)
    actor  = classify_actor(payload)            # 행위자: user | bot | unknown
    chat_id = extract_user_chat_id(payload)
    text    = extract_text(payload)
    owner_id = extract_owner_id(payload) or "unknown"

    fullname = extract_fullname(payload)
    f_name, l_name = split_name(fullname)

    if CHANNEL_DEBUG:
        logging.info("DBG :: actor=%s owner=%s chat=%s text=%r fullname=%r",
                     actor, owner_id, chat_id, text, fullname)

    if not chat_id:
        return JSONResponse({"ok": False, "reason": "no_userChatId_in_payload"})

    # 1) 사용자 행위 → 명령/일반 처리 + user 로그 기록
    if actor == "user":
        await _process_user_and_reply(owner_id, f_name, l_name, chat_id, text)
        return JSONResponse({"ok": True, "handled": "user"})

    # 2) 봇/플러그인 행위 → 같은 owner에게 bot 로그로 기록 (소유자 귀속)
    if actor == "bot":
        async with get_session() as s:
            await upsert_user(s, user_id=owner_id, name=combine_name(f_name, l_name))
            bot_log = ChatLog(channel_user_id=owner_id, role="bot", message=(text or "(내용 없음)"))
            s.add(bot_log)
            await s.commit()
            await s.refresh(bot_log)
            if CHANNEL_DEBUG:
                logging.info("DBG :: saved bot log_id=%s uid=%s msg=%r", bot_log.id, owner_id, text)
        return JSONResponse({"ok": True, "stored": "bot"})

    # 3) 알 수 없는 경우
    if CHANNEL_DEBUG:
        logging.info("DBG :: skipped unknown actor")
    return JSONResponse({"ok": True, "skipped": "unknown-actor"})